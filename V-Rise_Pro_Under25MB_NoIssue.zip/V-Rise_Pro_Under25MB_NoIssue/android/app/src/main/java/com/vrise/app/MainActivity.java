package com.vrise.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.provider.Settings;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.util.Calendar;

public class MainActivity extends Activity {
    WebView webView;
    static final String CHANNEL_ID = "vrise_alarm_channel";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        createChannel(this);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 10);
        }
        getWindow().setStatusBarColor(android.graphics.Color.parseColor("#020806"));
        getWindow().setNavigationBarColor(android.graphics.Color.parseColor("#020806"));
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new AndroidBridge(this), "AndroidBridge");
        webView.loadUrl("file:///android_asset/www/index.html");
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    public static void createChannel(Context ctx) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "V-Rise Alarms", NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("V-Rise reminder alarms");
            NotificationManager nm = ctx.getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }

    public static class AndroidBridge {
        Context ctx;
        AndroidBridge(Context c){ ctx = c; }

        @JavascriptInterface public void scheduleAlarm(String title, long triggerAtMillis, boolean repeating) {
            try {
                Intent i = new Intent(ctx, AlarmReceiver.class);
                i.putExtra("title", title);
                i.putExtra("repeating", repeating);
                Calendar cal = Calendar.getInstance();
                cal.setTimeInMillis(triggerAtMillis);
                i.putExtra("hour", cal.get(Calendar.HOUR_OF_DAY));
                i.putExtra("minute", cal.get(Calendar.MINUTE));
                int requestCode = (int)(System.currentTimeMillis() % 1000000);
                PendingIntent pi = PendingIntent.getBroadcast(ctx, requestCode, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                AlarmManager am = (AlarmManager)ctx.getSystemService(Context.ALARM_SERVICE);
                if (am == null) return;
                if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi);
                    Toast.makeText(ctx, "V-Rise alarm set. For exact alarm, allow exact alarms in settings.", Toast.LENGTH_LONG).show();
                } else if (Build.VERSION.SDK_INT >= 23) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi);
                    Toast.makeText(ctx, "V-Rise alarm set", Toast.LENGTH_SHORT).show();
                } else {
                    am.setExact(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi);
                    Toast.makeText(ctx, "V-Rise alarm set", Toast.LENGTH_SHORT).show();
                }
            } catch(Exception e) {
                Toast.makeText(ctx, "Alarm error: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
    }
}
