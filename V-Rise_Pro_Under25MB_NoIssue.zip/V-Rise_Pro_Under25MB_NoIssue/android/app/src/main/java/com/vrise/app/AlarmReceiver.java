package com.vrise.app;

import android.app.*;
import android.content.*;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import java.util.Calendar;

public class AlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        MainActivity.createChannel(context);
        String title = intent.getStringExtra("title");
        if (title == null || title.length() == 0) title = "V-Rise Reminder";
        Intent open = new Intent(context, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPi = PendingIntent.getActivity(context, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Uri sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        Notification.Builder nb = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(context, MainActivity.CHANNEL_ID) : new Notification.Builder(context);
        nb.setSmallIcon(com.vrise.app.R.mipmap.ic_launcher)
          .setContentTitle("V-Rise")
          .setContentText(title)
          .setContentIntent(openPi)
          .setAutoCancel(true)
          .setPriority(Notification.PRIORITY_HIGH)
          .setSound(sound);
        NotificationManager nm = (NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.notify((int)(System.currentTimeMillis() % 100000), nb.build());
        if (intent.getBooleanExtra("repeating", false)) {
            int hour = intent.getIntExtra("hour", 6);
            int minute = intent.getIntExtra("minute", 0);
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DAY_OF_YEAR, 1);
            cal.set(Calendar.HOUR_OF_DAY, hour);
            cal.set(Calendar.MINUTE, minute);
            cal.set(Calendar.SECOND, 0);
            cal.set(Calendar.MILLISECOND, 0);
            Intent next = new Intent(context, AlarmReceiver.class);
            next.putExtra("title", title);
            next.putExtra("repeating", true);
            next.putExtra("hour", hour);
            next.putExtra("minute", minute);
            PendingIntent pi = PendingIntent.getBroadcast(context, (hour*60+minute), next, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            AlarmManager am = (AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
            if (am != null) {
                if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pi);
                else am.setExact(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pi);
            }
        }
    }
}
