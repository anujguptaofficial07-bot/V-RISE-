const CACHE='vrise-pro-v1';
self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE).then(c=>c.addAll(['index.html','manifest.webmanifest','assets/icons/logo-192.png','assets/icons/logo-512.png','assets/vrise-alarm.wav'])))});
self.addEventListener('fetch',e=>{e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request))) });
