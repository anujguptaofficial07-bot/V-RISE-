# V-Rise Pro — Under 25MB Fixed Package

V-Rise is a routine + daily goals + alarm/reminder app.

## Size Fix
This version is optimized under 25MB. Heavy unused promo images were removed/replaced with lightweight motivation assets, so the app features remain intact.

## Open Web Version
1. Extract ZIP.
2. Open `index.html` in Chrome.

## Build APK with GitHub Actions
1. Upload the extracted folder contents to a GitHub repository.
2. Open **Actions**.
3. Run **Build V-Rise APK**.
4. Download the APK from **Artifacts**.

## Features
- Root `index.html`
- V-Rise splash/loading screen
- Name + wake-up time + main goal setup
- Daily goals and routine checklist
- Progress percentage and streak
- Alarm/reminder with web notification while open
- Android WebView project with native alarm bridge
- Focus timer
- Last 7 days progress chart
- Export backup JSON
- Local storage only: no login, no cloud

Important: Android 13+ may ask notification permission. Some phones require exact alarm permission for perfect alarm timing.
